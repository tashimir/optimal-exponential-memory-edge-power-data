# Online Resource 1

Supplement to Pedro M. M. de Castro, *Finite-horizon phase transitions in optimal exponential memory for Euclidean connections*, submitted to *Mathematical Methods of Operations Research*.

Centro de Informática, Universidade Federal de Pernambuco, Recife, Brazil. Correspondence: [pmmc@cin.ufpe.br](mailto:pmmc@cin.ufpe.br).

Begin with this guide for the purpose and reproduction commands, then consult the [data dictionary](DATA_DICTIONARY.md) for the complete file inventory and field definitions.

The numerical evidence is organized by scientific topic:

- `data/analytical_benchmarks`: exact one-dimensional costs, geometric constants, scalar-model calculations and a separate three-case cost check.
- `data/calibration_experiment`: the twelve-scenario comparison with an archived numerical finite-horizon parameter, including complete trajectory costs.
- `data/measured_calibration_gains`: all 259 scenarios of the expanded experiment, paired moments, fixed parameters, random-stream specification and observed gain-zero brackets.

Install Python dependencies with `python -m pip install -r requirements.txt`. Reconstruct every expanded estimate and interval with:

```sh
python code/calibration_statistics.py --output reconstructed_intervals.csv
python code/plot_calibration_gains.py --data data/measured_calibration_gains/expanded_calibration_results.csv --output reproduced_figures
```

Fig. 5(a) presents the 189 joint-window cases with r <= 2, with a circular magnification of the segment intersections near r = 0.5. All 217 joint-window cases, including the 28 with r > 2, remain in the data. Fig. 5(b) presents the 42 fixed-power cases on the same linear saving scale. Fig. 5(c) shows all 91 cost increases on a logarithmic axis, including those with r > 2, with circles for joint-window and triangles for fixed-power cases. Its highlighted curve gives the largest observed point estimate at each horizon within the 37 tested scenarios. Segments join the sampled estimates; their intersections are not certified continuous thresholds.

The expanded data use 32,768 independent trajectories per horizon. The same inputs are shared across the 37 scenarios and 74 policies within a horizon. Seven independent horizon streams contain 229,376 distinct input sequences. Estimates are percentage savings relative to the analytical stationary scale. Their intervals are pointwise paired normal delta-method intervals. Fixed-power scenarios give finite-sample sensitivity evidence. The supplied moments reconstruct all reported statistics; complete trajectory-cost arrays are retained by the author.

Regenerate the trajectories on GNU/Linux with a C++17 OpenMP compiler:

```sh
python code/reproduce_expanded_calibration.py --output regenerated_trajectories --threads 8
```

The full computation is intensive. Add `--horizons 256 --trajectories 128` for a small check of the first block. Blocks are reused after identity and checksum validation. Thread count and block boundaries do not change the random streams; floating-point bitwise agreement can depend on the compiler and mathematical library. Regenerate the parameter tables with `python code/prepare_calibration_parameters.py --benchmarks code --root regenerated_parameters`.

Run the separate numerical-reference experiment with `python code/calibration_experiment.py --output regenerated_reference_comparison`. Run the analytical checks with `python code/analytical_benchmarks.py`, and the three-case check with `python code/finite_cost_monte_carlo.py`; these last two commands write their outputs in `code`.

The source data, additional numerical arrays and the figure catalog are in [repository version v1.2.2](https://github.com/tashimir/optimal-exponential-memory-edge-power-data/tree/v1.2.2). `DATA_DICTIONARY.md` defines the columns and explains the distinction between analytical scales, numerical parameters, empirical brackets and certified results. The original multidimensional radial-Poisson solver is available from the author on reasonable request.
